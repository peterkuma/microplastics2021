//' Package for running path length simulations
//'
//' @name Rpathlength
//' @useDynLib Rpathlength, .registration=TRUE
//' @importFrom Rcpp sourceCpp
//' @exportPattern ^[[:alpha:]]+

#include <time.h>
#include <limits.h>
#include <ctype.h>
#include <string.h>
#include <sys/time.h>
#include <cstdlib>
#include <cstdio>

#include "boost/random.hpp"
#include "boost/generator_iterator.hpp"
#include <Rcpp.h>
// [[Rcpp::depends(RcppProgress)]]
#include <progress.hpp>
#include <progress_bar.hpp>


#include "./pathlength.h"
#include "geometry/geometry.h"
#include "geometry/constructor.h"

int find_bin_index(Rcpp::NumericVector breaks, double value, bool equispaced);

//' Run path length simulations
//'
//' @describeIn run_pathlength Run 3D general simulation
//'
//' @param Nray Number of rays to simulate
//' @param radius Radius of circle/sphere used to generate rays
//' @param shape Integer describing shape. Can take values \itemize{
//' \item{0 - Stadium}
//' }
//' @param shape_params Vector defining the shape.
//' @param seed The random seed to use (if \code{set_seed==TRUE})
//' @param set_seed Should the specified seed be used?
//' @param alphasca The scattering coefficient.
//' @param alphaabs The absorption coefficient.
//' @param n1 The refractive index of the surrounding medium.
//' @param n2 The refractive index of the sample.
//' @param max_its The number of iterations before truncation. If negative,
//' no truncation is done.
//' @param trim Should rays that miss be removed from results?
//' @param breaks If provided, a histogram is created of path lengths, with
//' these breaks. If not provided, then the individual ray statistics are
//' returned.
//' @param logl If true, then the base-10 logarithm of the path length is
//' taken before making the histogram.
//' @param equispaced Are the breaks equispaced?
//' @param no_summary Should the summary-printing be suppressed?
//' @param extra_debug Should some extra debugging messages be printed.
//' Possibly \emph{very} slow.
//' @param return_z If true, then the final position, direction, and normal
//' are returned (only if \code{make_rays} is true)
//' @param count_histogram If true, histograms of the number of bounces of
//' scattering, and interface interactions, are returned (in the same data.frame).
//' @param normalise_by_hitting Path lengths are normalised by rays hitting
//' the sample.
//' @param only_count_hitting Rays that miss the sample are entirely
//' disregarded. Useful for pushing the number of rays up.
//' @param display_progress If true, a progress bar is displayed
//' @param make_rays Should a data.frame of rays be returned?
//' @param make_summary Should a summary data.frame be returned?

//' @return A list, with possible fields "hist", "rays", "counthist",
//' "summary"
//'
// [[Rcpp::export]]
Rcpp::List run_pathlength(int Nray = 10000000, double radius = 2.5,
                          int shape = 0,
                          Rcpp::NumericVector shape_params =
                              Rcpp::NumericVector::create(0.75, 1.5, 0, 0, 0, 0),
                              int seed = 0, bool set_seed = false,
                              double alphasca = 1,
                              double alphaabs = 0, double n1 = 1, double n2 = 1,
                              int max_its = 2000, bool trim = true,
                              Rcpp::NumericVector breaks =
                                      Rcpp::NumericVector::create(),
                                      bool logl = true, bool equispaced = false,
                                      bool no_summary = false,
                                      bool extra_debug = false,
                                      bool return_z = false,
                                      bool count_histogram = false,
                                      bool normalise_by_hitting = true,
                                      bool only_count_hitting = true,
                                      bool display_progress = true,
                                      bool make_rays = false,
                                      bool make_summary = false) {
    // now returns a list
    int i;
    int i_enter = 0;
    Ray ray;
    double lastlength = 0;

    int numbins = breaks.size()+1;
    // number of bins ;
    Rcpp::List retlist = Rcpp::List();
    // lengths outside the range get put in first or last bins!
    bool make_histogram = (numbins >= 2);

    //summary things
    int ntrapped = 0;
    int nabsorbed = 0;
    // histogram things
    Rcpp::IntegerVector bins;
    Rcpp::DataFrame histogram;
    Rcpp::DataFrame summary_frame;

    // rays things
    Rcpp::DataFrame status_frame;
    Rcpp::NumericVector ltot;
    Rcpp::IntegerVector ninterface;
    Rcpp::IntegerVector ninterfaceTIR;
    Rcpp::IntegerVector nscatter;
    Rcpp::IntegerVector region;
    Rcpp::NumericVector xlist;
    Rcpp::NumericVector ylist;
    Rcpp::NumericVector zlist;
    Rcpp::NumericVector uxlist;
    Rcpp::NumericVector uylist;
    Rcpp::NumericVector uzlist;
    Rcpp::NumericVector nxlist;
    Rcpp::NumericVector nylist;
    Rcpp::NumericVector nzlist;
    Rcpp::NumericVector exitangle;
    Rcpp::NumericVector entryangle;
    Rcpp::NumericVector lastlengthVec;

    // count histogram things
    Rcpp::IntegerVector scatterhist;
    Rcpp::IntegerVector interfacehist;
    Rcpp::IntegerVector interfaceTIRhist;

    // other things
    Rcpp::IntegerVector counts(3);
    double u_sum = 0;

    double plength, lsum;


    if (shape < Shape_Min || shape > Shape_Max) {
        REprintf("Please specify valid shape, got %d\n", shape);
        return(NULL);
    }
    if (count_histogram && max_its < 0) {
        REprintf("Unable to make a count histogram when max_its < 0\n");
        return(NULL);
    }

    double shape_params_arr[6];
    // make a 6-array, with (up to) the first 6 elements of shape_params
    for (int i = 0; i < shape_params.size() && i < 6; i++) {
        shape_params_arr[i] = shape_params[i];
    }
    Geometry* geom = MakeGeometry(shape_params_arr, static_cast<Shape>(shape));

    Point normal;
    if (!set_seed) {
        seed = time(NULL);
    }
    set_random_seed(seed);

    int scatterStatusInt = 0;
    int interfaceStatusInt = 0;
    int interfaceTIRStatusInt = 0;
    int absorbedStatusInt = 0;
    int trappedStatusInt = 0;

    if (make_rays) {


        ninterface = Rcpp::IntegerVector(Nray);
        nscatter = Rcpp::IntegerVector(Nray);
        ninterfaceTIR = Rcpp::IntegerVector(Nray);
        ltot = Rcpp::NumericVector(Nray);
        // region can have values 0 [outside],
        // 1 [inside, absorbed], 2[inside, trapped]
        region = Rcpp::NumericVector(Nray);
        exitangle = Rcpp::NumericVector(Nray);
        entryangle = Rcpp::NumericVector(Nray);
        lastlengthVec = Rcpp::NumericVector(Nray);
        status_frame = Rcpp::DataFrame::create(Rcpp::_["L"] = ltot,
                                               Rcpp::_["scatter"] = nscatter,
                                               Rcpp::_["interface"] = ninterface,
                                               Rcpp::_["outcome"] = region,
                                               Rcpp::_["entryangle"] =
                                                   entryangle,
                                                   Rcpp::_["exitangle"] =
                                                       exitangle,
                                                       Rcpp::_["lastlength"] =
                                                           lastlengthVec);
        if (return_z) {
            xlist = Rcpp::NumericVector(Nray);
            ylist = Rcpp::NumericVector(Nray);
            zlist = Rcpp::NumericVector(Nray);
            uxlist = Rcpp::NumericVector(Nray);
            uylist = Rcpp::NumericVector(Nray);
            uzlist = Rcpp::NumericVector(Nray);
            nxlist = Rcpp::NumericVector(Nray);
            nylist = Rcpp::NumericVector(Nray);
            nzlist = Rcpp::NumericVector(Nray);
            status_frame.push_back(xlist, "x");
            status_frame.push_back(ylist, "y");
            status_frame.push_back(zlist, "z");
            status_frame.push_back(uxlist, "ux");
            status_frame.push_back(uylist, "uy");
            status_frame.push_back(uzlist, "uz");
            status_frame.push_back(nxlist, "nx");
            status_frame.push_back(nylist, "ny");
            status_frame.push_back(nzlist, "nz");
        }


    }
    if (make_histogram) {
        bins = Rcpp::IntegerVector(numbins);
    }
    if (count_histogram && max_its > 0) {
        scatterhist = Rcpp::IntegerVector(max_its + 2);
        interfacehist = Rcpp::IntegerVector(max_its + 2);
        interfaceTIRhist = Rcpp::IntegerVector(max_its + 2);
        for (i = 0; i < max_its + 1; i++) {
            scatterhist[i] = 0;
            interfacehist[i] = 0;
            interfaceTIRhist[i] = 0;
        }
    }


    lsum = 0;
    // initialize to zero...
    counts[0] = 0;
    counts[1] = 0;
    counts[2] = 0;

    bool success = false;
    if (!no_summary) {
        Rprintf("#*****Summary of options *****\n");
        Rprintf("#--three_dimensions\n");

        Rprintf("#--shape %d\n", geom->get_shape_id());
        Rprintf("#--a %1.20f\n", geom->get_params()[0]);
        Rprintf("#--b %1.20f\n", geom->get_params()[1]);
        Rprintf("#--c %1.20f\n", geom->get_params()[2]);
        Rprintf("#--d %1.20f\n", geom->get_params()[3]);
        Rprintf("#--e %1.20f\n", geom->get_params()[4]);
        Rprintf("#--f %1.20f\n", geom->get_params()[5]);
        Rprintf("#--radius %1.20f\n", radius);
        Rprintf("#--n1 %1.20f\n", n1);
        Rprintf("#--n2 %1.20f\n", n2);
        Rprintf("#--alphasca %1.20f\n", alphasca);
        Rprintf("#--alphaabs %1.20f\n", alphaabs);
        Rprintf("#--nray %d\n", Nray);
        Rprintf("#--max_its %d\n", max_its);
        Rprintf("#--seed %ul\n", seed);
        Rprintf("#--return_z %d\n", return_z);
        Rprintf("# --make_rays %d\n", make_rays);
        Rprintf("# --make_summary %d\n", make_summary);
        Rprintf("# --make_histogram %d\n", make_histogram);
        Rprintf("# --count_histogram %d\n", count_histogram);
    }

    Progress pb(Nray, display_progress);


    for (i = 0; i < Nray; i++) {
        pb.update(i);
        if (i % 10000 == 0)Rcpp::checkUserInterrupt();
        trappedStatusInt = 0;
        scatterStatusInt = 0;
        absorbedStatusInt = 0;
        interfaceStatusInt = 0;
        interfaceTIRStatusInt = 0;

        if (make_rays) {
            nscatter[i] = 0;
            ninterface[i] = 0;
            // init to 0
            ltot[i] = 0;
        }
        ray = make_incident_ray(geom, radius, &normal,
                                extra_debug, &interfaceStatusInt);

        Point incident_direction = ray.u;

        if(interfaceStatusInt != 0){//make sure we're actually inside...
                                    int move_counter = 0;
                                    while (!geom->is_inside(ray.r) && move_counter++ < 10){
                                        ray = propagate_ray(ray, TEPS);
                                    }
        }
        if (make_rays) {
            ninterface[i] = interfaceStatusInt;
            nscatter[i] = scatterStatusInt;
        }
        if(interfaceStatusInt == 0){
            //missing

            if (only_count_hitting) {
                // we only care about hitting rays, so decrease i
                // and try again
                i--;
            } else {
                counts[0]++;
                if (make_rays) {
                    ninterface[i] = 0;
                    nscatter[i] = 0;
                }
                // if making histogram, we don't care about missing photons
            }


        } else {
            i_enter++;

                success = hit_interface(&ray, normal, n1, n2, extra_debug,
                                        false)==1;


            if (success) {
                if (make_rays) {
                    // note that this angle is the inside angle (after any
                    // refraction)
                    entryangle[i] = acos(dot_product_d(normal, ray.u));
                }
                plength = follow_ray_inside(&ray, geom, i_enter, n1, n2,
                                            alphasca, alphaabs,
                                            max_its, &scatterStatusInt,
                                            &interfaceStatusInt,
                                            &interfaceTIRStatusInt,
                                            &absorbedStatusInt,
                                            &trappedStatusInt,
                                            extra_debug,
                                            &lastlength, &normal);

                if (count_histogram && max_its > 0) {
                    scatterhist[scatterStatusInt]++;
                    interfacehist[interfaceStatusInt]++;
                    interfaceTIRhist[interfaceTIRStatusInt]++;

                }
                if (make_summary){
                    if (absorbedStatusInt > 0){
                        nabsorbed++;
                    }
                    if (trappedStatusInt > 0 && max_its > 0) {
                        ntrapped++;
                    }
                    //TIR events are included in interfaceStatusInt.
                }
                if (make_rays) {
                    ltot[i] = plength;

                    nscatter[i] = scatterStatusInt;
                    ninterface[i] = interfaceStatusInt;
                    ninterfaceTIR[i] = interfaceTIRStatusInt;
                    if (absorbedStatusInt > 0) {
                        region[i] = 1;
                    }
                    if (trappedStatusInt == 1 && max_its > 0) {
                        region[i] = 2;
                    }
                    // if we are not making a histogram, then we should keep
                    // track of exit angles this is just theta, not tracking phi
                    // due to symmetry the exit angle is the angle *after*
                    // refraction
                    exitangle[i] = acos(dot_product_d(normal, ray.u));
                    lastlengthVec[i] = lastlength;
                }

                    counts[2]++;
                    lsum+=plength;



                    if (make_histogram) {
                        if (logl) {
                            plength = std::log10(plength);
                        }
                        bins[find_bin_index(breaks, plength, equispaced)]++;
                    }


            } else {
                // record entry angle for rays that don't enter
                // If they reflect, then theta doesn't change, so
                // I shouldn't need to worry about that
                if (make_rays) {
                    // note that this angle is the inside angle (after any
                    // refraction)
                    entryangle[i] = acos(dot_product_d(multiply_p(normal, -1),
                                                       ray.u));
                    // exitangle==entryangle for rays that reflect, other rays
                    // this is updated later.
                    exitangle[i] = entryangle[i];
                }

                counts[1]++;
                if (make_histogram) {
                    // pathlength is zero
                    // but if that's in a bin, we should add it.
                    if (logl) {
                        plength = std::log10(0);
                    } else {
                        plength = 0;
                    }
                    bins[find_bin_index(breaks, plength, equispaced)]++;
                }
                if (make_rays) {
                    ninterface[i] = 1;
                    ninterfaceTIR[i] = 0;
                    nscatter[i] = 0;
                    // -1 is hitting, but not entering
                    region[i] = 0;
                }
                if (count_histogram && max_its > 0) {
                    scatterhist[scatterStatusInt]++;
                    interfacehist[interfaceStatusInt]++;
                    interfaceTIRhist[interfaceTIRStatusInt]++;
                }

            }
            // if return_z is set, then we return final coordinates
            // now in separate columns
            if (return_z && make_rays) {
                xlist[i] = ray.r.x;
                ylist[i] = ray.r.y;
                zlist[i] = ray.r.z;
                uxlist[i] = ray.u.x;
                uylist[i] = ray.u.y;
                uzlist[i] = ray.u.z;
                nxlist[i] = normal.x;
                nylist[i] = normal.y;
                nzlist[i] = normal.z;
            }
            Point final_direction = ray.u;
            u_sum += dot_product_d(incident_direction, final_direction);
        }
    }

    if (make_histogram) {
        Rcpp::NumericVector col(numbins);
        Rcpp::NumericVector mids(numbins);
        Rcpp::NumericVector width(numbins);
        Rcpp::NumericVector L(numbins);
        Rcpp::NumericVector pL(numbins);

        width[0] = 0;
        width[numbins - 1] = 0;
        mids[0] = -INFINITY;
        mids[numbins - 1] = INFINITY;
        L[0] = -INFINITY;
        L[numbins - 1] = INFINITY;

        //this is the count in the column
        for (i = 0; i < col.size(); i++) {
            col[i] = static_cast<double>(bins[i]);
        }
        for (i = 1; i < numbins-1; i++) {
            // don't normalise first or last
            // normalise rest by width of bin and number of hitting photons
            // or entering rays, as appropriate
            if (normalise_by_hitting) {
                col[i] = (col[i]) / ((breaks[i] - breaks[i-1]) *
                    (counts[1]+counts[2]));
            } else {
                col[i] = (col[i]) / ((breaks[i] - breaks[i-1]) * (counts[2]));
            }
            width[i] = breaks[i] - breaks[i-1];
            mids[i] = (breaks[i] + breaks[i-1])/2;
            if (logl) {
                L[i] = pow(10, mids[i]);
                pL[i] = col[i]*1.0 / L[i] / std::log(10);

            }
        }

        histogram = Rcpp::DataFrame::create(Rcpp::_["p"] = col,
                                            Rcpp::_["Lmean"] =
                                                lsum/(counts[1] + counts[2]));
        histogram.push_back(bins, "counts");
        histogram.push_back(width, "width");
        histogram.push_back(mids, "mids");
        if (logl) {
            histogram.push_back(L, "L");
            histogram.push_back(pL, "pL");
        }
        histogram = Rcpp::as<Rcpp::DataFrame>(histogram);

    }

    if (make_rays) {
        if (trim) {
            // Remove all entries that missed
            // If only_count_hitting is true, there shouldn't be any
            Rcpp::LogicalVector statusTemp = Rcpp::LogicalVector(Nray);
            for (int i = 0; i < Nray; i++){
                //Ray missed if it's outside, and never hit an interface
                statusTemp[i] = region[i] == 0 && ninterface[i] == 0;
            }
            Rcpp::DataFrame tempframe = Rcpp::DataFrame::create();
            for (Rcpp::DataFrame::iterator i = status_frame.begin();
                 i != status_frame.end(); i++){
                Rcpp::NumericVector vector = *i;
                vector = vector[statusTemp == false];
                tempframe.push_back(vector);
            }
            tempframe.names() = status_frame.names();
            status_frame = tempframe;
        }
        retlist.push_back(status_frame, "rays");

    }
    if (make_histogram) {
        retlist.push_back(histogram, "hist");
    }

    if (count_histogram && max_its > 0) {
        Rcpp::NumericVector scattercountdensity = Rcpp::NumericVector(max_its + 2);
        Rcpp::NumericVector interfacecountdensity = Rcpp::NumericVector(max_its + 2);
        Rcpp::NumericVector interfaceTIRcountdensity = Rcpp::NumericVector(max_its + 2);
        for (i = 0; i < max_its + 2; i++) {
            scattercountdensity[i] = scatterhist[i] * 1.0 / (counts[1] + counts[2]);
            interfacecountdensity[i] = interfacehist[i] * 1.0 / (counts[1] + counts[2]);
            interfaceTIRcountdensity[i] = interfaceTIRhist[i] * 1.0 / (counts[1] + counts[2]);
            // normalise
        }

        Rcpp::DataFrame countframe = Rcpp::DataFrame::create(
            Rcpp::_["bounces"] = Rcpp::seq(0, max_its + 1),
            Rcpp::_["Nscatter"] = scatterhist,
            Rcpp::_["pscatter"] = scattercountdensity,
            Rcpp::_["Ninterface"] = interfacehist,
            Rcpp::_["pinterface"] = interfacecountdensity,
            Rcpp::_["NinterfaceTIR"] = interfaceTIRhist,
            Rcpp::_["pinterfaceTIR"] = interfaceTIRcountdensity);
        retlist.push_back(countframe, "counthist");
    }
    if (make_summary) {
        summary_frame = Rcpp::DataFrame::create(
            Rcpp::_["lmean"] = lsum/(counts[1] + counts[2]),
            Rcpp::_["Nray"] = counts[0] + counts[1] + counts[2],
            Rcpp::_["Nreflected"] = counts[1], // Reflected without entering
            Rcpp::_["Nmissing"] = counts[0], // Missing
            Rcpp::_["Ntrapped"] = ntrapped,
            Rcpp::_["Nabsorbed"] = nabsorbed,
            Rcpp::_["Ntransmitted"] = counts[1] + counts[2] -
            ntrapped - nabsorbed,
            Rcpp::_["g"] = u_sum / (counts[1] + counts[2] -
            ntrapped - nabsorbed)
        );
        retlist.push_back(summary_frame, "summary");
    }


    delete(geom);
    R_FlushConsole();
    R_ProcessEvents();
    R_CheckUserInterrupt();
    return(retlist);
}
