//'
//' @file fresnel.h
//' @author wrcs
//' @brief Functions to do with crossing boundaries
//'
//' This provides utility functions that used when crossing a boundary.
#ifndef SRC_FRESNEL_H_
#define SRC_FRESNEL_H_

#include <stdbool.h>
#include <stdio.h>
#include "./util.h"


//'
//' \brief Works out direction of ray hitting an interface
//'
//' \param [in,out] ray The ray of interest, will be updated with new direction
//' \param [in] normal The normal to the surface, pointing from n1 to n2
//' \param [in] n1 The refractive index in the medium the ray is in
//' \param [in] n2 The refractive index in the other medium
//' \param [in] inside Is the ray (starting from) inside the object
//' \return Return an int indicating what happened to the ray.
//' Return 1 if the ray changes medium (and is now in n2), 2 if it TIRs,
//' and 0 if it reflects (but not TIR).
//'
//' \details This works out the new direction for the ray after hitting
//' an interface, and either reflecting or refracting. The normal should
//' point from n1 to n2. The ray will be updated with a new direction,
//' and for some geometries may be propagated some small distance.
//'
//'
int hit_interface(Ray *ray, Point normal, double n1, double n2,
                   bool extraDebug, bool inside);


//'
//' \brief Calculate the Lambertian reflectance of a surface
//'
//' \param [in] relative_n Relative refractive index n2/n1
//' \return Return the Lambertian reflectance
//'
//' \details This returns the Lambertian reflectance of an interface
//' (averaged over incident angles).The limit as n->1 is
//' 1/2+ n^2*(n^2-1)^2/((n^2+1)^3)*log((n-1)/(n+1)) +
//' (n-1)*(3*n+1)/(6*(n+1)^2) - 2*n^3*(n^2+n-1)/((n^4-1)*(n^2+1)) +
//' 8*n^4*(n^4+1)*log(n)/((n^4-1)^2*(n^2+1))
//'
double get_lambertian_reflectance(double relative_n);




//'
//' \brief Reflect a ray
//'
//' \param [in/out] ray Ray to be reflected
//' \param [in] normal The normal of the surface to reflect off
//' \return Returns 0 in normal operation. No other return values supported
//'
//' \details This reflects the ray "ray", according to the surface normal.
//' Returns the reflected ray in place.
//'
int get_reflected_ray(Ray *ray, Point normal);




//'
//' \brief Refract a ray
//'
//' \param [in/out] ray Ray to be refracted
//' \param [in] normal The normal of the surface to refract through
//' \param [in] n1 The refractive index of the medium the ray is in
//' \param [in] n2 The refractive index of the medium the ray is going into
//' \return Returns 0 in normal operation, and 1 if the ray undergoes
//' total internal reflection
//'
//' \details This refracts the ray "ray", according to the surface normal,
//' as it goes from n1 to n2. In the case that there is total internal
//' reflection, this returns the reflected ray, and returns 1.
//'
int get_refracted_ray(Ray *ray, Point normal, double n1, double n2);

#endif  // SRC_FRESNEL_H_
