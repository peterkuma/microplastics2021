#include <Rcpp.h>
#include "geometry/geometry.h"
#include "./util.h"
#include "geometry/stadium.h"
#include "geometry/constructor.h"


//' Functions for calculating surface areas and volumes
//' @describeIn surface_area_ Calculate a single surface area,
//' for a specified shape
//'
//' If a parameter is not required for that shape, it may be omitted.
//'
//'
//' @param shape Integer specifying shape, as in \code{run_pathlength}
//' @param a First parameter of shape
//' @param b Second parameter of shape
//' @param c Third parameter of shape
//' @param d Fourth parameter of shape
//' @param e Fifth parameter of shape
//' @param f Sixth parameter of shape
//' @param params Vector of parameters
//' @param shape Vector (or length one) representing shape
//'
//' @return The requested quantity, as a double, or vector of doubles.
//' If the quantity is not defined, returns -1.
//' If the shape is invalid, returns -2.
//'
//' @seealso run_pathlength
// [[Rcpp::export]]
double surface_area_(int shape, double a, double b, double c,
                     double d, double e, double f) {
    Shape s = static_cast<Shape>(shape);
    if (s<Shape_Min || s>Shape_Max) {
        return(-2);
    }
    double params[6] = {a, b, c, d, e, f};
    Geometry* g = MakeGeometry(params, s);
    double sa = g->get_surface_area();
    delete(g);
    return(sa);
}

//' @describeIn surface_area_ Calculate a single volume, for a specified shape
// [[Rcpp::export]]
double volume_(int shape, double a, double b, double c,
               double d, double e, double f) {
    Shape s = static_cast<Shape>(shape);
    if (s<Shape_Min || s>Shape_Max) {
        return(-2);
    }
    double params[6] = {a, b, c, d, e, f};
    Geometry* g = MakeGeometry(params, s);
    double v = g->get_volume();
    delete(g);
    return(v);
}

//' @describeIn surface_area_ Calculate surface area for a given list of shapes
//'
// [[Rcpp::export]]
Rcpp::NumericVector surface_area(Rcpp::IntegerVector shape, Rcpp::List params) {
    int count = params.length();
    if (shape.length() != count && shape.length() != 1) {
        Rcpp::stop("Length of shape and params must be equal,"
                       "or shape must have length 1");
    }
    bool oneshape = shape.length() == 1;
    int s;
    Rcpp::NumericVector area(count);
    double p[6];
    for (int i = 0; i < count; i++) {
        Rcpp::NumericVector pthis = params[i];
        for (int j = 0; j < 6; j++) {
            if (pthis.length() >= j) {
                p[j] = pthis[j];
            } else {
                p[j] = 0;
            }
        }
        s = oneshape?shape[0]:shape[i];
        area[i] = surface_area_(s, p[0], p[1], p[2], p[3], p[4], p[5]);
    }
    return(area);
}

//' @describeIn surface_area_ Calculate volume for a given list of shapes
//'
// [[Rcpp::export]]
Rcpp::NumericVector volume(Rcpp::IntegerVector shape, Rcpp::List params) {
    int count = params.length();
    if (shape.length() != count && shape.length() != 1) {
        Rcpp::stop("Length of shape and params must be equal, "
                       "or shape must have length 1");
    }
    bool oneshape = shape.length() == 1;
    int s;
    Rcpp::NumericVector area(count);
    double p[6];
    for (int i = 0; i < count; i++) {
        Rcpp::NumericVector pthis = params[i];
        for (int j = 0; j < 6; j++) {
            if (pthis.length() >= j) {
                p[j] = pthis[j];
            } else {
                p[j] = 0;
            }
        }
        s = oneshape?shape[0]:shape[i];
        area[i] = volume_(s, p[0], p[1], p[2], p[3], p[4], p[5]);
    }
    return(area);
}








//' Generate shape parameters
//'
//' This generates shape parameters for different shapes and aspect ratios,
//' with the condition that the mean path length (for unity refactive
//' index) is one.
//'
//' For shapes where there is no mean path length, an appropriate set of
//' parameters are returned.
//'
//' @param shape A vector of length 1, or the same length as h, specifying
//' shapes, as in \code{run_pathlength}.
//' @param h A vector of desired aspect ratios. If a given aspect ratio is
//' not possible for a given shape, the parameters will be \code{NA}.
//'
// [[Rcpp::export]]
Rcpp::List generate_shape_params(Rcpp::IntegerVector shape,
                                 Rcpp::NumericVector h) {
    int count = h.length();
    if (shape.length() != count && shape.length() != 1) {
        Rcpp::stop("Length of shape and h must be equal, "
                       "or shape must have length 1");
    }

    bool oneshape = shape.length() == 1;
    Shape s;
    Rcpp::List results(count);
    double params[6];
    for (int i = 0; i < count; i++) {
        s = static_cast<Shape>(oneshape?shape[0]:shape[i]);
        MakeShapeParams(h[i], 1, params, s);
        Rcpp::NumericVector nv(6);
        for (int j = 0; j < 6; j++)nv[j] = params[j];
        results[i] = nv;

    }
    return(results);
}



//' Functions for calculating minimum radius to use
//' @describeIn surface_area_ Calculate a single minimum radius,
//' for a specified shape
//'
//' If a parameter is not required for that shape, it may be omitted.
//'
//'
//' @param shape Integer specifying shape, as in \code{run_pathlength}
//' @param a First parameter of shape
//' @param b Second parameter of shape
//' @param c Third parameter of shape
//' @param d Fourth parameter of shape
//' @param e Fifth parameter of shape
//' @param f Sixth parameter of shape
//' @param params Vector of parameters
//' @param shape Vector (or length one) representing shape
//'
//' @return The requested quantity, as a double, or vector of doubles.
//' If the quantity is not defined, returns -1.
//' If the shape is invalid, returns -2.
//'
//' @seealso run_pathlength
// [[Rcpp::export]]
double min_radius_(int shape, double a, double b, double c,
                   double d, double e, double f) {
    Shape s = static_cast<Shape>(shape);
    if (s<Shape_Min || s>Shape_Max) {
        return(-2);
    }
    double params[6] = {a, b, c, d, e, f};
    Geometry* g = MakeGeometry(params, s);
    double mr = g->get_minimum_radius();
    delete(g);
    return(mr);
}

//' @describeIn surface_area_ Calculate minimum radius for a given list of shapes
//'
// [[Rcpp::export]]
Rcpp::NumericVector min_radius(Rcpp::IntegerVector shape, Rcpp::List params) {
    int count = params.length();
    if (shape.length() != count && shape.length() != 1) {
        Rcpp::stop("Length of shape and params must be equal,"
                       "or shape must have length 1");
    }
    bool oneshape = shape.length() == 1;
    int s;
    Rcpp::NumericVector mr(count);
    double p[6];
    for (int i = 0; i < count; i++) {
        Rcpp::NumericVector pthis = params[i];
        for (int j = 0; j < 6; j++) {
            if (pthis.length() >= j) {
                p[j] = pthis[j];
            } else {
                p[j] = 0;
            }
        }
        s = oneshape?shape[0]:shape[i];
        mr[i] = min_radius_(s, p[0], p[1], p[2], p[3], p[4], p[5]);
    }
    return(mr);
}
