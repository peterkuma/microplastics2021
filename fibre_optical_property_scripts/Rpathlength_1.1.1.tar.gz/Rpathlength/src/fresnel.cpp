#include "fresnel.h"

int hit_interface(Ray *ray, Point normal, double n1, double n2,
                   bool extraDebug, bool inside) {
    double relative_n = n1/n2;
    double A, Rp, Rs, Rtot, dice;
    // my normal is defined as travelling from the medium the ray is currently
    // in, to the other medium (from n1 to n2)
    double udotn = dot_product_d(ray->u, normal);
 //   Rprintf("To start, fp = %f, fs=%f\n", fp, fs);
    int retval = 0;
    if (relative_n == 1) {
        // strictly one, transmit
        retval = 1;
    } else {
        // test for TIR
        double deltaP = 1 - relative_n * relative_n * (1 - udotn * udotn);
        if (deltaP > 0) {
            // the ray is not totally-internally-reflected
            // it might still be reflected
            A = sqrt(deltaP);
            // two reflection coefficients
            Rp = (((udotn) - relative_n*A)/((udotn) + relative_n*A)) *
                (((udotn) - relative_n*A)/((udotn) + relative_n*A));
            Rs = (((udotn) - 1.0/relative_n*A)/((udotn) + 1.0/relative_n*A)) *
                (((udotn) - 1.0/relative_n*A)/((udotn) + 1.0/relative_n*A));
            Rtot = (Rs+Rp)/2;
            dice = make_rand_d(0, 1);
            if (extraDebug)Rprintf("We threw %f compared to %f (%f, %f)\n"
                                       "udotn = %f, relative_n = %f, A=%f\nn.z "
                                       "= %f, u.z=%f\n",
                                       dice, Rtot, Rp, Rs, udotn,
                                       relative_n, A, normal.z, ray->u.z);
            if (dice > Rtot) {
                // refracted

                get_refracted_ray(ray, normal, n1, n2);
                retval = 1;
            } else {
                get_reflected_ray(ray, normal);
                retval = 0;
            }
        } else {
            // ray is reflected
            get_reflected_ray(ray, normal);

            retval = 2;
        }

    }


    return(retval);
}

double get_lambertian_reflectance(double relative_n) {
    double term1, term2, term3, term4, term5;
    double n, n2, n3, n4;
    n = relative_n;
    n2 = n*n;
    n3 = n2*n;
    n4 = n3*n;
    if (relative_n == 1)return(0);
    term1 = 1.0/2.0;
    term2 = (n - 1) * (3 * n + 1)/(6 * (n + 1)* (n + 1));
    term3 = -2 * n3 * (n2 + 2*n - 1) / ((n4 - 1) * (n2 + 1));
    term4 = 8 * n4 * (n4 + 1) * log(n) / ((n4 - 1) * (n4 - 1) * (n2 + 1));
    term5 = n2 * (n2 - 1) * (n2 - 1) / ((n2 + 1) * (n2 + 1) * (n2 + 1)) *
        log((n - 1) / (n + 1));
    return(term1 + term2 + term3 + term4 + term5);
}


int get_reflected_ray(Ray *ray, Point normal) {
    double udotn = dot_product_d(ray->u, normal);
    ray->u = normalise_p(add_p(ray->u, multiply_p(normal, -2*udotn)));
    return(0);
}


int get_refracted_ray(Ray *ray, Point normal, double n1, double n2) {
    double relative_n = n1/n2;
    double udotn = dot_product_d(ray->u, normal);
    double deltaP = 1-relative_n*relative_n*(1-udotn*udotn);
    if (deltaP > 0) {
        double A = sqrt(deltaP);
        double alp = A - relative_n * udotn;

        ray->u = normalise_p(add_p(multiply_p(normal, alp),
                                   multiply_p(ray->u, relative_n)));
        return(0);
    } else {
        get_reflected_ray(ray, normal);
        return(1);
    }
}
