#include "./pathlength.h"

double follow_ray_inside(Ray *ray, Geometry* g, int index, double n_out,
                         double n_in, double alphasca, double alphaabs,
                         int max_its, int *scatterstatus,
                         int *interfacestatus, int *interfacetirstatus,
                         int* absorbedstatus, int* trappedstatus,
                         bool extra_debug,
                         double *last_length, Point *normal) {
    double t_sample, t_sca, t_abs;
    double rand_sca, rand_abs;
    double plength = 0;
    int escaped;
    int i;
    int confused_counter = 0;
    if (extra_debug)REprintf("Ray #%d at (%1.20f, %1.20f, %1.20f, %1.20f, "
                                 "%1.20f, %1.20f)\n", index,
                                 ray->r.x, ray->r.y, ray->r.z,
                                 ray->u.x, ray->u.y, ray->u.z);

                {//make sure we're actually inside...
                    int move_counter = 0;
                    while (!g->is_inside(ray->r) && move_counter++ < 100){
                        //   Rprintf("Ray #%d is not inside, but we are in follow_inside()\n", index);
                        *ray = propagate_ray(*ray, TEPS);
                    }
                    //Rprintf("inside = %d\n", g->is_inside(ray->r));
                }
                for (i = 0; max_its < 0 || i < max_its; max_its < 0 || i++) {

                    // find when ray will scatter, absorb
                    rand_sca = make_rand_d(0, 1);
                    rand_abs = make_rand_d(0, 1);

                    t_sca = -1 / alphasca * log(1 - rand_sca);
                    t_abs = -1 / alphaabs * log(1 - rand_abs);

                    // find when ray will intersect edge of sample
                    t_sample = g->intersect_from_inside(*ray, normal, fmin(t_sca, t_abs), extra_debug);
                    if (extra_debug){
                        REprintf("Hitting, at t=%f; status=(%d, %d)\n", t_sample, scatterstatus[0], interfacestatus[0]);
                        REprintf("u = (%f, %f, %f), n=(%f, %f, %f), and u.n=%f\n", ray->u.x, ray->u.y, ray->u.z, normal->x, normal->y, normal->z, dot_product_d(ray->u, *normal));
                        if(dot_product_d(ray->u, *normal) < 0)REprintf("That's odd, why is u.n negative?\n");
                    }

                    if (t_sample < 0) {
                        Rprintf("We should be inside (at (%f, %f, %f), r=%f),"
                                    "but t_sample=%1.20f\n",
                                    ray->r.x, ray->r.y, ray->r.z,
                                    length_d(ray->r), t_sample);
                        Rprintf("isinside = %d\n", g->is_inside(ray->r));
                        if (confused_counter > 10){
                            absorbedstatus[0] = 1; //kind of a lie, but best option
                            return(plength);
                        }
                        confused_counter++;
                    }
                    // absorb before scatter or hit edge
                    if (t_abs < t_sca && t_abs < t_sample) {
                        plength += t_abs;
                        *ray = propagate_ray(*ray, t_abs);
                        if (extra_debug)REprintf("Ray absorbed after %d iterations "
                                                     "and %f pathlength\n", i+1, plength);
                        absorbedstatus[0] = 1;
                        *last_length = t_abs;
                        return(plength);
                    }
                    // scatter before hitting edge
                    if (t_sca <= t_sample && std::isfinite(t_sca)) {
                        scatterstatus[0]++;
                        plength += t_sca;
                        *ray = propagate_ray(*ray, t_sca);
                        if (extra_debug)REprintf("Scattering after l=%f, status=(%d, %d)\n",
                            plength, scatterstatus[0], interfacestatus[0]);
                        ray->u = make_new_direction_p(ray->u);
                        *last_length = t_sca;
                    } else {
                        interfacestatus[0]++;
                        // hit edge of sample
                        plength += t_sample;
                        *ray = propagate_ray(*ray, t_sample);
                        *last_length = t_sample;


                        if (extra_debug)REprintf("Ray going to interface, at (%1.20f, "
                                                     "%1.20f, %1.20f, %1.20f, %1.20f, "
                                                     "%1.20f)\n, normal = (%1.20f, %1.20f, %1.20f), status=(%d, %d)\n",
                                                     ray->r.x, ray->r.y, ray->r.z,
                                                     ray->u.x, ray->u.y, ray->u.z,
                                                     normal->x, normal->y, normal->z,
                                                     scatterstatus[0], interfacestatus[0]);
                        // increase counter of hitting sample egde
                        //

                        bool want_to_leave = false;


                        if ((escaped =
                            hit_interface(ray, *normal, n_in, n_out,
                                          extra_debug, true))==1) {
                            if (extra_debug)REprintf("Ray escaped (%1.20f, %1.20f, %1.20f, "
                                                         "%1.20f, %1.20f, %1.20f), "
                                                         "status=(%d, %d)\n",
                                                         ray->r.x, ray->r.y, ray->r.z,
                                                         ray->u.x, ray->u.y, ray->u.z,
                                                         scatterstatus[0], interfacestatus[0]);
                            if (plength < 1e-7 && extra_debug) {
                                Rprintf("That's odd; %d its, at (%f, %f, %f, %f, %f, %f), "
                                            "l=%1.20f\n", i, ray->r.x, ray->r.y, ray->r.z,
                                            ray->u.x, ray->u.y, ray->u.z, plength);
                            }
                            want_to_leave = true;
                            //when leaving, we don't count surface scattering on the way out
                        } else {
                            // didn't leave, move a bit away from interface
                            int move_counter = 0;
                            while (!g->is_inside(ray->r) && move_counter++ < 10){
                                *ray = propagate_ray(*ray, TEPS);
                            }
                            if(escaped == 2){
                                interfacetirstatus[0]++;
                            }
                            want_to_leave = false;
                        }



                        if(want_to_leave)return(plength);
                        if (extra_debug)REprintf("Ray trapped (%1.20f, %1.20f, %1.20f, "
                                                     "%1.20f, %1.20f, %1.20f), status=(%d, %d)\n",
                                                     ray->r.x, ray->r.y, ray->r.z,
                                                     ray->u.x, ray->u.y, ray->u.z,
                                                     scatterstatus[0], interfacestatus[0]);
                    }

                }
                // hit max_its
                if (extra_debug)REprintf("Ray dies after after %d iterations and %f "
                                             "pathlength (scattering %d times, "
                                             "hitting edge %d times)\n",
                                             i, plength,
                                             scatterstatus[0], interfacestatus[0]);
                trappedstatus[0]++;
                if (plength < TEPS) {
                    Rprintf("That's odd\n");
                }
                return(plength);
}
