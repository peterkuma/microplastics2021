#ifndef SRC_PATHLENGTH_H_
#define SRC_PATHLENGTH_H_
#include <stdio.h>
#include "./util.h"
#include "geometry/geometry.h"
#include "./fresnel.h"


//'
//'  \brief Follow a ray to determine its pathlength
//'
//'  \param [in,out] ray The ray to follow, is changed to the final state
//'  (when it leaves/is absorbed)
//'  \param [in] g The geometry of the sample
//'  \param [in] index The index of the photon (used for output)
//'  \param [in] n_out The refractive index outside the sample
//'  \param [in] n_in The refractive index of the sample
//'  \param [in] alphasca The scattering coefficient
//'  \param [in] alphaabs The absorption coefficient
//'  \param [in] anisotropy The anisotropy factor
//'  \param [in] max_its Maximum number of iterations
//'  \param [in,out] scatterstatus Address of an int, that stores number of
//'  scatters the ray lives for (after entering);
//'  \param [in,out] interfacestatus Address of an int, that stores number of
//'  interface hits the ray lives for (after entering);
//'  \param [in,out] interfacestatus Address of an int, that stores number of
//'  interface hits the ray lives for (after entering) where it undergoes TIR;
//'  \param [out] absorbedstatus Address of an int, that is set to 1 if the
//'  ray is absorbed.
//'  \param [out] trappedstatus Address of an int, that is incremented if the
//'  ray is trapped.
//'  \param [out] last_length The length travelled on the last bounce (until
//'  exit, death, or absorption)
//'  \param [out] normal The normal to the surface where the ray exits.
//'  Undefined, possibly NULL, if the ray does not exit.
//'  \return Return The pathlength of the ray inside the sample
//'
//'  \details This tracks a single ray that is already inside the sample.
//'  That ray might scatter in the sample,
//'   be absorbed, hit the edge of the sample and reflect, or hit the edge
//'   of the sample and exit the sample.that
//'
//'   Note that if max_its is negative, there will be no cutoff. Otherwise,
//'   the max possible value is 2^31-1. In the case of no cutoff, simulations
//'   might run forever. Make sure in such a case that a count histogram is
//'   not made.
//'
//'
double follow_ray_inside(Ray *ray, Geometry* g, int index, double n_out,
                         double n_in, double alphasca, double alphaabs,
                         int max_its, int *scatterstatus,
                         int *interfacestatus, int *interfacetirstatus,
                         int* absorbedstatus, int* trappedstatus,
                         bool extra_debug,
                         double *last_length, Point *normal);

#endif  // SRC_PATHLENGTH_H_
