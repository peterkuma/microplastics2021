#ifndef SRC_GEOMETRY_GEOMETRY_H_
#define SRC_GEOMETRY_GEOMETRY_H_
#include <stdbool.h>
#include <stdio.h>
#include <math.h>
#include "../util.h"

#define TEPS 1E-14

//'
//'  @brief enum listing possible sample shapes
//'
//'
typedef enum {STADIUM,
              Shape_Min = STADIUM,
              Shape_Max = STADIUM} Shape;



class Geometry {
 public:
    explicit Geometry(double params[6]) {
        this->params = params;
    }
    virtual ~Geometry() {}
    virtual bool is_inside(Point p) const = 0;
    virtual double intersect_from_inside(Ray ray, Point *normal, double max_length,
                                         bool extra_debug)  = 0;
    virtual double intersect_from_outside(Ray ray, Point *normal, double max_length,
                                          bool extra_debug)  = 0;
    virtual double intersect_both(Ray ray, bool inside, Point *normal, double max_length,
                                  bool extra_debug)  = 0;
    virtual double get_surface_area() const = 0;
    virtual double get_volume() const = 0;
    virtual double get_minimum_radius() const = 0;
    double* get_params() const {
        return (this->params);
    }
    Shape get_shape_id() const {
        return (this->shape_id);
    }
 protected:
    double* params;
    Shape shape_id;
};

#endif  // SRC_GEOMETRY_GEOMETRY_H_
