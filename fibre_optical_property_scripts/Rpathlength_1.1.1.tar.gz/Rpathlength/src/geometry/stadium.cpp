#include "./stadium.h"

Stadium::Stadium(double params[6]) : Geometry(params) {
    this->radius = params[0];
    this->height = params[1];
    this->shape_id = STADIUM;
    this->base_height = this->height/2.0 - this->radius;
    //this shape has hemispheres radius radius, and a total height height
    //that must be >= 2*radius
    //so the "tips" of the spheres are at +/-height/2
}


bool Stadium::is_within_sides(Point r) const {
    return (r.x*r.x + r.y*r.y < this->radius*this->radius);
}

bool Stadium::is_between_ends(Point r) const {
    // that is, ends of the cylindrical part,
    // which go from z=-height/2 + radius to z=height/2 - radius
    return (r.z > - this->base_height && r.z < this->base_height);
}

bool Stadium::is_in_cap(Point r) const {
    //in either hemispherical cap part

    return( is_in_top_cap(r) || is_in_bottom_cap(r));
}

bool Stadium::is_in_top_cap(Point r) const {
    //in the top hemispherical cap part


    //return(r.z >= this->base_height && (r.x*r.x + r.y*r.y + (r.z - this->base_height)*(r.z - this->base_height)) < this->radius * this->radius);
    return(r.z >= this->base_height);
}

bool Stadium::is_in_bottom_cap(Point r) const {
    //in the bottom hemispherical cap part


    //return(r.z <= -this->base_height && (r.x*r.x + r.y*r.y + (r.z + this->base_height)*(r.z + this->base_height)) < this->radius * this->radius);
    return(r.z <= -this->base_height);
}

bool Stadium::is_inside(Point p) const {
    return((is_within_sides(p) && is_between_ends(p)) || length_d(add_p(p, {0,0,this->base_height})) < this->radius || length_d(add_p(p, {0,0,-this->base_height})) < this->radius);
}

double Stadium::intersect_from_inside(Ray ray, Point *normal, double max_length,
                                       bool extra_debug)  {
    return( intersect_both(ray, true, normal, max_length, extra_debug) );
}

double Stadium::intersect_from_outside(Ray ray, Point *normal, double max_length,
                                        bool extra_debug)  {
    return( intersect_both(ray, false, normal, max_length, extra_debug) );
}


double Stadium::intersect_both(Ray ray, bool inside, Point *normal, double max_length,
                                bool extra_debug)  {
    // for a stadium, the parameters are radius, total height,
    double rdotuxy;
    double rdotu;
    double t_top = -1;
    double t_bottom = -1;
    double t_cir = -1;
    double t, t0, t1, t1_b;
    double len_uxy_sq;
    int multiplier = (inside?1:-1);
    bool side_between_ends, top, bottom;
    int whichface = -1;
    // will be 0 if hits top cap, 1 if hits bottom cap, 2 if hits side

    Ray hit_top, hit_bottom, hit_side;
    rdotu = dot_product_d(ray.r, ray.u);

    //if we're inside and in the sphere, take second (+ve) root
    //one root must be +ve, one -ve
    //else inside and outside sphere, take second root
    //both roots must have same sign
    //either case, take second root
    //top cap
    inside && quadratic_root(1, 2*rdotu - 2*ray.u.z*this->base_height, dot_product_d(ray.r, ray.r) -
        this->radius*this->radius - 2*ray.r.z*this->base_height+this->base_height*this->base_height, &t1, &t_top);
    //bottom cap
    inside && quadratic_root(1, 2*rdotu + 2*ray.u.z*this->base_height, dot_product_d(ray.r, ray.r) -
        this->radius*this->radius + 2*ray.r.z*this->base_height+this->base_height*this->base_height, &t1_b, &t_bottom);
    //outside, take first root
    //top cap
    !inside && quadratic_root(1, 2*rdotu - 2*ray.u.z*this->base_height, dot_product_d(ray.r, ray.r) -
        this->radius*this->radius - 2*ray.r.z*this->base_height+this->base_height*this->base_height, &t_top, &t1);
    //bottom cap
    !inside && quadratic_root(1, 2*rdotu + 2*ray.u.z*this->base_height, dot_product_d(ray.r, ray.r) -
        this->radius*this->radius + 2*ray.r.z*this->base_height+this->base_height*this->base_height, &t_bottom, &t1_b);

    if(std::isinf(t_top))t_top = -1;
    if(std::isinf(t_bottom))t_bottom = -1;

    top = false;
    bottom = false;
    side_between_ends = false;
    hit_top = propagate_ray(ray, t_top);
    hit_bottom = propagate_ray(ray, t_bottom);
    hit_side = ray;  // just to make sure it's initialised
    if (t_top >= TEPS)top = is_in_top_cap(hit_top.r);
    if (t_bottom >= TEPS)bottom = is_in_bottom_cap(hit_bottom.r);
    if(t_top >= TEPS && !top && t1 > 0 && std::isfinite(t1)){
        hit_top = propagate_ray(ray, t1);

        if((top = is_in_top_cap(hit_top.r))){
            t_top = t1;
        }
    }
    if(t_bottom >= TEPS && !bottom && t1_b > 0 && std::isfinite(t1_b)){
        hit_bottom = propagate_ray(ray, t1_b);

        if((bottom = is_in_bottom_cap(hit_bottom.r))){
            t_bottom = t1_b;
        }
    }
    //if we hit the sphere, but not in the cap part, then we don't hit.
    if(t_top >= TEPS && !top)t_top = -1;
    if(t_bottom >= TEPS && !bottom)t_bottom = -1;

    //check we hit the top from the correct side:
    //normal on top is just the position on the cap (within normalisation) - base_height
    if(top && dot_product_d(ray.u, add_p(hit_top.r, {0, 0, -this->base_height})) * multiplier < 0){
        //we seem to be hitting from the wrong side
        top = false;
        t_top= -1;
        //REprintf("(cc-cap) u = (%f, %f, %f), n=(%f, %f, %f), and u.n=%f\n", ray.u.x, ray.u.y, ray.u.z, hit_top.r.x, hit_top.r.y, hit_top.r.z, dot_product_d(ray.u, hit_top.r));
    }

    //check we hit the bottom from the correct side:
    //normal on bottom is just the position on the cap (within normalisation) + base_height
    if(bottom && dot_product_d(ray.u, add_p(hit_bottom.r, {0, 0, +this->base_height})) * multiplier < 0){
        //we seem to be hitting from the wrong side
        bottom = false;
        t_bottom= -1;
        //REprintf("(cc-cap) u = (%f, %f, %f), n=(%f, %f, %f), and u.n=%f\n", ray.u.x, ray.u.y, ray.u.z, hit_bottom.r.x, hit_bottom.r.y, hit_bottom.r.z, dot_product_d(ray.u, hit_bottom.r));
    }
    if ((inside || is_within_sides(ray.r)) && (top || bottom)) {
        // we're inside the infinite cylinder, and we hit the top or bottom
        // within the infinite cylinder
        // hence one of them must be the solution
        if (top ^ bottom) {  // only one is at a positive time
            whichface = top?0:1;
            t = top?t_top:t_bottom;
        } else {
            whichface = (t_top < t_bottom)?0:1;
            t = fmin(t_top, t_bottom);
        }
    } else {
        // we need to solve for hitting the side
        rdotuxy = ray.r.x * ray.u.x + ray.r.y * ray.u.y;
        len_uxy_sq = ray.u.x * ray.u.x + ray.u.y * ray.u.y;

        if (quadratic_root(len_uxy_sq, 2*rdotuxy, ray.r.x * ray.r.x +
           ray.r.y * ray.r.y - this->radius*this->radius, &t0, &t1)) {
            // here, it's not inside the cylinder that matters, but inside
            // the infinite cylinder
            if (t0 == t1 && extra_debug) {
                Rprintf("It looks like we have a repeated root...\n");
            }
            if (!is_within_sides(ray.r)) {
                // we're outside infinite cylinder, so there are either zero
                // positive roots, or two positive roots
                if (t0 < TEPS && t1 < TEPS) {
                    // both roots in past, no solution
                    t_cir = -1;
                } else if (t0 > TEPS && inside) {
                    // both in future, but we're inside,
                    // so the first one isn't real
                    t_cir = t1;
                } else if (t0 > TEPS) {
                    // we're outside, take first one
                    t_cir = t0;
                } else {
                    // This is odd
                    t_cir = t1;
                }
            } else {
                // we're inside, so there are two solutions
                // we should take the largest one
                t_cir = t1;
                if (t0 > t1 && extra_debug) {
                    REprintf("That's odd, t0 > t1, %f > %f\n", t0, t1);
                }
                if (t1 < 0 && extra_debug)REprintf("Negative\n");
            }


        } else {
            t_cir = -1;
        }
        // these check it if hits the right part of the cylinder, and after t=0
        if (t_cir >= TEPS) {
            hit_side = propagate_ray(ray, t_cir);
            side_between_ends = is_between_ends(hit_side.r);
        }

        if (inside && side_between_ends) {
            // actually, if we're inside then at this point we must hit the side
            whichface = 2;
            t = t_cir;
        } else {
            // so far have covered all inside cases, plus outside cases inside
            // infinite cylinder
            if (side_between_ends) {
                // this will hit a side between the ends, check if it hit
                // the ends first)
                if (top && (t_top < t_cir)) {
                    // we hit the top before hitting the side
                    whichface = 0;
                    t = t_top;
                } else if (bottom && (t_bottom < t_cir)) {
                    // we hit the bottom before hitting the sides
                    whichface = 1;
                    t = t_bottom;
                } else {
                    // we hit the sides before hitting the bottom
                    whichface = 2;
                    t = t_cir;
                }
            } else {
                // we just hit top and bottom
                if (top && (t_top < t_bottom || t_bottom <= TEPS || bottom)) {
                    whichface = 0;
                    t = t_top;
                } else if (bottom && (t_bottom < t_top || t_top <= TEPS)) {
                    whichface = 1;
                    t = t_bottom;
                }
            }
        }
    }
    // there was no solution, but we're really close to a wall;
    // set that as the intersection
    // note we only do this if we're inside, as then we're sure we have to hit.
    if (inside && whichface == -1 && fabs(t_cir) < TEPS) {
        // hit side, but very close
        whichface = 2;
        t = 0;
    }
    if (inside && whichface == -1 && fabs(t_top) < TEPS) {
        // hit cap, but very close
        whichface = 0;
        t = 0;
    }
    if (inside && whichface == -1 && fabs(t_bottom) < TEPS) {
        // hit side, but very close
        whichface = 1;
        t = 0;
    }
    if (whichface == -1) {
        if (extra_debug && is_inside(ray.r)) {
            REprintf("Problem, we're inside (%d) (at (%1.20f, %1.20f, %1.20f, "
            "%1.20f, %1.20f, %1.20f) but don't hit?"
            "\nt_top=%f\nt_bottom=%f\nt_cir=%f\nt1=%f\nt0=%f\n",
                     inside, ray.r.x, ray.r.y, ray.r.z,
                     ray.u.x, ray.u.y, ray.u.z, t_top, t_bottom, t_cir, t1, t0);
            REprintf("top - %d\nbottom - %d\ncir - %d\n",
                     top, bottom, side_between_ends);
            REprintf("Hits top at (%f, %f, %f), a distance^2 of %f, a^2 is %f\n",
                     hit_top.r.x, hit_top.r.y, hit_top.r.z,
                     (hit_top.r.x*hit_top.r.x + hit_top.r.y*hit_top.r.y),
                     this->radius*this->radius);
            REprintf("Hits bottom at (%f, %f, %f), a distance^2 of %f, a^2 is %f\n",
                     hit_bottom.r.x, hit_bottom.r.y, hit_bottom.r.z,
                     (hit_bottom.r.x*hit_bottom.r.x +
                         hit_bottom.r.y*hit_bottom.r.y),
                         this->radius*this->radius);
            REprintf("Hits side at z=%f, between %f and %f\n",
                     hit_side.r.z, -this->base_height, this->base_height);
        }
        return(-1);
    }

    if (extra_debug && fabs(t) < TEPS) {
        REprintf("t is very small %1.20f, hitting face %d; inside is %d, "
        "within_sides is %d\n",
                 t, whichface, inside, is_within_sides(ray.r));
        if (whichface == 2)
            REprintf("options were %1.20f and %1.20f\n", t0, t1);
    }
    if (normal != NULL) {
        switch (whichface) {
        case 0:  // hit cap
            *normal = {hit_top.r.x, hit_top.r.y, hit_top.r.z - this->base_height};//cap normal is cap position
            break;
        case 1:
            *normal = {hit_bottom.r.x, hit_bottom.r.y, hit_bottom.r.z + this->base_height};//cap normal is cap position
            break;
        case 2:
            *normal = {hit_side.r.x, hit_side.r.y, 0};
            break;
        }
        *normal = multiply_p(normalise_p(*normal), multiplier);
        // if we're already inside, it should be outward
    }
    return(t);
}


double Stadium::get_volume() const {
    return (M_PI*this->radius*this->radius*(this->height - 2*this->radius/3.0));
}

double Stadium::get_surface_area() const {
    //area of ends = pi * r^2 + 4*pi*r^2/2
    return (2*M_PI*this->radius*this->height);
}

void Stadium::make_shape_params(double h, double mean, double *params) {
    for (int i = 0; i < 6; i++) {
        params[i] = 0;
    }
    if (h < 1) {
        for (int i = 0; i < 6; i++) {
            params[i] = NAN;
        }
    } else {
        double radius = mean * h/2.0/(h-1.0/3.0);
        double height =2*radius*h;
        params[0] = radius;
        params[1] = height;
        params[2] = 0;
        params[3] = 0;
        params[4] = 0;
        params[5] = 0;
    }
    return;
}

double Stadium::get_minimum_radius() const{
    if (this->height < 2*this->radius){
        REprintf("Height=%f is smaller than twice radius (2*%f), potentially a problem\n", this->height, this->radius);
    }
    return (this->height/2.0);
}
