#ifndef SRC_GEOMETRY_CONSTRUCTOR_H_
#define SRC_GEOMETRY_CONSTRUCTOR_H_

#include "../util.h"
#include "./geometry.h"
#include "./stadium.h"



//' Construct a geometry
//'
//' @param params A 6-array of the shape parameters to use
//' @param shape Which type of shape to construct
//' @return A pointer to a Geometry object of the requested type
//'
//' @usage
//' This calls the constructor of the appropriate geometry type.
//' If shape is not valid, then a null pointer is returned.
Geometry* MakeGeometry(double params[6], Shape shape);

//' Make shape parameters for a given shape, aspect ratio, and mean pathlength
//' @describeIn MakeShapeParams Make parameters for 3D shape
//'
//' @param h The desired aspect ratio. For some shapes, may be less than 1.
//' @param mean The desired mean path length
//'  (for a sample of unity relative refractive index).
//' @param params A pointer to a double array of length 6 or greater.
//' If length is less than 6, this will segfault, as it writes 6 values.
//' @param shape The shape to generate parameters for.
//'
//' @return Results are put in params. If the shape is invalid,
//' or the aspect ratio is not obtainable for that shape,
//' the result will be filled with NAN.
void MakeShapeParams(double h, double mean, double* params, Shape shape);


#endif  // SRC_GEOMETRY_CONSTRUCTOR_H_
