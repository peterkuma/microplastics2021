#include "./constructor.h"

Geometry* MakeGeometry(double params[6], Shape shape) {
    Geometry* geom;
    if (shape == STADIUM)geom = new Stadium(params);
    return(geom);
}

void MakeShapeParams(double h, double mean, double* params, Shape shape) {
   if (shape == STADIUM) {
        Stadium::make_shape_params(h, mean, params);
    } else {
        for (int i = 0; i < 6; i++) {
            params[i] = NAN;
        }
    }
}
