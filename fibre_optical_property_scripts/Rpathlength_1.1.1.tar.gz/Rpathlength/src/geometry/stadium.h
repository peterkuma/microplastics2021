#ifndef SRC_GEOMETRY_STADIUM_H_
#define SRC_GEOMETRY_STADIUM_H_
#include <stdbool.h>
#include <stdio.h>
#include <math.h>
#include "../util.h"
#include "./geometry.h"

class Stadium : public Geometry {
 public:
    explicit Stadium(double params[6]);
    ~Stadium() {}
    bool is_inside(Point p) const;
    double intersect_from_inside(Ray ray, Point *normal, double max_length,
                                 bool extra_debug) ;
    double intersect_from_outside(Ray ray, Point *normal, double max_length,
                                  bool extra_debug) ;
    double intersect_both(Ray ray, bool inside, Point *normal, double max_length,
                          bool extra_debug) ;
    double get_surface_area() const;
    double get_volume() const;
    double get_minimum_radius() const;
    static void make_shape_params(double h, double mean, double* params);

 private:
     double radius;
     double height;
     double base_height;
     bool is_between_ends(Point p) const;
     bool is_within_sides(Point p) const;
     bool is_in_cap(Point p) const;
     bool is_in_top_cap(Point p) const;
     bool is_in_bottom_cap(Point p) const;
};

#endif  // SRC_GEOMETRY_STADIUM_H_
