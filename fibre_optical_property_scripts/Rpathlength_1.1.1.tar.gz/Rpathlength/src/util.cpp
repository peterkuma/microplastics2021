#include "./util.h"
#include "geometry/geometry.h"
double length_d(Point p) {
  return( sqrt(dot_product_d(p, p)) );
}


Point normalise_p(Point p) {
  double length = length_d(p);
  Point p2 = multiply_p(p, 1.0/length);
  return(p2);
}

Point multiply_p(Point p, double a) {
  Point p2 = {p.x * a, p.y * a, p.z * a};
  return(p2);
}

Point add_p(Point p1, Point p2) {
  Point p3 = {p1.x + p2.x, p1.y + p2.y, p1.z + p2.z};
  return(p3);
}

Point subtract_p(Point p1, Point p2) {
  return( add_p(p1, multiply_p(p2, -1)) );
}

Ray propagate_ray(Ray ray, double t) {
  Point initial_pos = ray.r;
  Point initial_dir = ray.u;
  Point change =  multiply_p(initial_dir, t);
  Ray new_ray = {add_p(initial_pos, change), ray.u};
  return( new_ray );
}

#ifdef __GNUG__
boost::mt19937 generator;
#endif

double make_rand_d(double min_d, double max_d) {
  if(min_d == max_d){
    Rcpp::warning("min_d == max_d == %f\n", min_d);
    return(min_d);
  }
#ifdef __GNUG__
  // need generator to be defined
  boost::uniform_real<> uni_dist(min_d, max_d);
  boost::variate_generator<boost::mt19937&,
                           boost::uniform_real<> > uni(generator, uni_dist);
  return(uni());
#else
  return ( (max_d-min_d)*(rand_r() /static_cast<double>(RAND_MAX) ) + min_d );
#endif
}

Ray make_rand_ray(double radius) {
  Point p1 = multiply_p(make_rand_p(), radius);
  Point p2 = multiply_p(make_rand_p(), radius);
  Point u = subtract_p(p2, p1);
  u = normalise_p(u);
  Ray ray = {p1, u};
  return(ray);
}


double dot_product_d(Point p1, Point p2) {
  return (p1.x * p2.x + p1.y * p2.y + p1.z * p2.z);
}

Point cross_product_p(Point p1, Point p2) {
  Point result = {p1.y*p2.z - p1.z*p2.y,
                  p1.z*p2.x-p1.x*p2.z,
                  p1.x*p2.y-p1.y*p2.x};
  return (result);
}

Point make_rand_p() {
  double theta1 = acos(make_rand_d(-1, 1));
  double phi1 = make_rand_d(0, 2 * M_PI);
  double rx = sin(theta1)*cos(phi1);
  double ry = sin(theta1)*sin(phi1);
  double rz = cos(theta1);

  Point p = {rx, ry, rz};
  return(p);
}


Point make_new_direction_p(Point u) {
  Point newdir = make_rand_p();
  return(newdir);

}

bool quadratic_root(double a, double b, double c, double *t0, double *t1) {
  double q, del;

  del = b*b - 4*a*c;
  if (del < 0) {
    // no real roots
    *t0 = INFINITY;
    *t1 = INFINITY;
    return(false);
  }

  // this method is described on page 118 of
  // Physically Based Rendering, Pharr and Humphreys
  if (b < 0) {
    q = -0.5*(b - sqrt(del));
    // we want t0 to be -b - sqrt()
    *t1 = q/a;
    *t0 = c/q;
    if (*t0 > *t1)Rprintf("Order 1 - q=%f, t0=%f, t1=%f\n", q, *t0, *t1);
  } else {
    q = -0.5*(b + sqrt(del));
    *t0 = q/a;
    *t1 = c/q;
    if (*t0 > *t1)Rprintf("Order 2\n");
  }

  if (*t0 < 0 && *t1 < 0)return(false);
  return(true);
}

void set_random_seed(unsigned int seed) {
#ifdef __GNUG__
  generator.seed(seed);
#else
  srand(seed);
#endif
  return;
}

Point rotate_vector_p(Point p1, Point p2, double theta) {
  // formula is
  // v_rot = p1 *\cos\theta + (p2 x p1)\sin\theta + p2(p2.p1)*(1-\cos\theta)
  double costheta = cos(theta);
  double sintheta = sin(theta);
  Point p2xp1 = cross_product_p(p2, p1);
  double p2dotp1 = dot_product_d(p2, p1);
  Point intermediate = add_p(multiply_p(p2xp1, sintheta),
                             multiply_p(p2, p2dotp1 * (1-costheta)));
  Point result = add_p(multiply_p(p1, costheta), intermediate);
  return(result);
}

Ray make_incident_ray(Geometry *geom, double radius,
                      Point *normal,
                      bool extra_debug, int* status){
  // First, we generate a ray (or not, as appropriate)
  // The first stage is to get the ray at the surface.
  // Slabs hit at (0,0,0)
  Ray ray;
  double t;
  *status = 0;

  ray = make_rand_ray(radius);

  //set up ray, now get it to hit surface
  t = geom->intersect_from_outside(ray, normal, 2*radius, extra_debug);
  if (t < 0) {
    // We miss ; set the status to indicate that, and return
    // write_trajectory(trajectory_file, full_trajectories, i, ray,
    //                     Nray, radius, false);
    // should trajectories be handled here, or outside this function?
    // Leave it out for now
    return(ray);
  }
  ray = propagate_ray(ray, t);
  // Now, get the direction
  // For non-lambertian slabs, and most shapes where !hit_at_point
  // then the angle doesn't need to change
  //
  *status = 1;
  return(ray);
}
