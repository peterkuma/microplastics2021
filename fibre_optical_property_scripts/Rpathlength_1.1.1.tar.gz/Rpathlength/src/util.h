#ifndef SRC_UTIL_H_
#define SRC_UTIL_H_



#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <stdbool.h>
#include <stdio.h>
#ifdef __GNUG__
#include <boost/random.hpp>
#endif
#include <Rcpp.h>


#ifndef M_PI
#define M_PI           3.14159265358979323846  // pi
#endif


//'
//'  @brief Struct representing a point
//'  This represents a point, and that point is often used to represent a vector
//'  (from the origin to this point).
//'
typedef struct {
    double x;
    double y;
    double z;
} Point;


//'
//'  @brief Struct representing a ray
//'  A ray has a position r and a direction u. All are represented as points.
//'  In the future, other information about the ray may also go in here.
//'
typedef struct {
    Point r;
    Point u;
} Ray;


//'
//'  \brief Calculate the length of some vector
//'
//'  \param [in] p The point of interest
//'  \return Return a double of the length of the vector
//'
//'  \details Calculates the length of a vector, which is
//'  formed from the origin to the point p.
//'
double length_d(Point p);

//'
//'  \brief Normalise a vector
//'
//'  \param [in] p The tip of the vector to normalise
//'  \return Return a point at the tip of a new vector of length one, that is
//'  parallel to the original vector
//'
//'  \details Given some point p which is at the tip of a vector,
//'  returns a point which is at the tip of a parallel vector of length one.
//'
Point normalise_p(Point p);

//'
//'  \brief Multiplies a point by a scalar
//'
//'  \param [in] p Some point to multiply
//'  \param [in] a A double to multiply the point by
//'  \return Return a new point which is the element-wise product of p and a.
//'
//'  \details Used to scale points linearly.
//'
Point multiply_p(Point p, double a);

//'
//'  \brief Add together two vectors
//'
//'  \param [in] p1 A point at the tip of a vector to be added
//'  \param [in] p2 A point at the tip of a vector to be added
//'  \return Return A point at the tip of the sum to the two vectors
//'
//'  \details Adds two vectors, represented by their tips (p1 + p2).
//'
Point add_p(Point p1, Point p2);


//'
//'  \brief Subtract two vectors
//'
//'  \param [in] p1 A point at the tip of a vector
//'  \param [in] p2 A point at the tip of a vector to be subtracted
//'  \return Return A point at the tip of the difference to the two vectors
//'
//'  \details The difference of two vectors, represented by their
//'  tips (p1 - p2).
//'
Point subtract_p(Point p1, Point p2);

//'
//'  \brief Work out the position of a ray at a later time
//'
//'  \param [in] ray The ray to move
//'  \param [in] t How long to move it for
//'  \return A new ray at the position ray would be in, with the same direction
//'  as ray.
//'
//'  \details This propagates ray from ray.r along ray.u for time t. It does
//'  not consider interfaces/boundaries,
//'  so t must be small enough for that not to be a problem.
//'
Ray propagate_ray(Ray ray, double t);

//'
//'  \brief Generate a random number
//'
//'  \param [in] min_d The lower end of the range
//'  \param [in] max_d The upper end of the race
//'  \return Return a random double between min_d and max_d
//'
//'  \details This calculates a random double from a uniform distribution
//'  between min_d and max_d (inclusive)
//'
double make_rand_d(double min_d, double max_d);

//'
//'  \brief Generates a random ray on a sphere
//'
//'  \param [in] radius The radius of the sphere the ray sits on
//'  \return Return a ray somewhere on the sphere, with some direction
//'  into the sphere
//'
//'  \details This generates a single random ray, placed at a random position
//'  on a sphere with a given radius, and oriented to a random direction
//'  into the sphere. The ray has a random polarisation.
//'
Ray make_rand_ray(double radius);



//'
//'  \brief Make a random unit vector
//'
//'  \return A point at the tip of a unit vector
//'
//'  \details This generates a point with length one, and a uniform distribution
//'
Point make_rand_p();


//'
//'  \brief Make a random unit vector
//'
//'  \param [in] u The initial direction
//'
//'  \return A point at the tip of a unit vector
//'
//'  \details This generates a point with length one, and an isotropic distribution.
Point make_new_direction_p(Point u);



//'
//'  \brief Calculate dot product
//'
//'  \param [in] p1 The end of one vector
//'  \param [in] p2 The end of one vector
//'  \return Return the dot product of p1 and p2
//'
//'  \details Calculates the dot product
//'  p = p1.x * p2.x + p1.y * p2.y + p1.z * p2.z
//'  Here, p1 and p2 represent the ends of vectors, as the
//'  dot product is defined on vectors and not points.
//'

double dot_product_d(Point p1, Point p2);

//'
//'  \brief Calculate cross product
//'
//'  \param [in] p1 The end of one vector
//'  \param [in] p2 The end of one vector
//'  \return Return the cross product of p1 and p2
//'
//'  \details Calculates the cross product p1 x p2
//'  Here, p1 and p2 represent the ends of vectors, as the cross
//'  product is defined on vectors and not points.
//'
Point cross_product_p(Point p1, Point p2);

//'
//'  \brief Solve quadratic equation
//'
//'  \param [in] a Coefficient of t^2
//'  \param [in] b Coefficient of t^1
//'  \param [in] c Coefficient of t^0
//'  \param [in] t0 Pointer to t0, where to store result
//'  \param [in] t1 Pointer to t1, where to store result
//'  \return Return true if a real root is found, false otherwise.
//'
//'  \details This solves the quadratic equation 0= a*t^2  b*t + c
//'  If there are no real roots, returns false. If there are real roots,
//'  returns into t0 and t1 (- and + roots respectively)
//'  This guarantees that t1 > t0.
//'
bool quadratic_root(double a, double b, double c, double *t0, double *t1);



//'
//'  \brief Set random seed
//'
//'  \param [in] seed Seed to use
//'
//'  \details This sets a random seed appropriate for the random generator
//'  being used.
//'
void set_random_seed(unsigned int seed);


//'
//'  \brief Rotate a vector
//'
//'  \param [in] p1 The vector to be rotated
//'  \param [in] p2 The vector around which to rotate
//'  \param [in] theta The angle in [rad] to rotate by
//'  \return Return the rotated vector
//'
//'  \details This rotates p1 around p2 by theta radians.
//'  It uses Rodrigues' rotation formula to calculate the new vector
//'
Point rotate_vector_p(Point p1, Point p2, double theta);

class Geometry;

//' \brief Generate incident ray
//' \param geom The shape we are considering.
//' \param radius The radius of the sphere used to generate rays.
//' \param extra_debug Should some extra debugging information be printed?
//' \param status This is set to 1 if the ray hits the interface, and 0 otherwise.
//' \return A ray, which is at the surface, with some direction.
//'
//' \details This tries to manage the complicated logic around generating rays.
//'
Ray make_incident_ray(Geometry *geom, double radius,
                      Point *normal,
                      bool extra_debug, int* status);



#endif  // SRC_UTIL_H_
