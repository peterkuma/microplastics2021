#include <Rcpp.h>
#include "./fresnel.h"

//' Get the index of a bin
//'
//' This assumes values outside the range go into the first (too small) or
//' last (too large) bins.
//' All other entries go in bins in between those.
//'
//' @param breaks A vector specifying the breaks between bins
//' @param value The value to put in a bin
//' @param equispaced Are the bins equispaced?
//'
//' @return The index of the bin the value goes into
int find_bin_index(Rcpp::NumericVector breaks, double value, bool equispaced) {
  int i;
  if (equispaced) {
    // we can assume equispaced points, that should be much faster
    double binwidth = breaks[1] - breaks[0];
    if (value < breaks[0])return(0);
    if (value > breaks[breaks.size()-1])return(breaks.size());
    return(1 + static_cast<int>((value-breaks[0])/binwidth));
  }
  for (i = 0; i < breaks.size(); i++) {
    if (value <= breaks[i]) {
      return(i);
    }
  }
  return(breaks.size());
}

//' Calculate Lambertian reflectances
//'
//' @param n Refractive index vector
//'
//' Calculates the reflectance for light averaged over a Lambertian distribution
//' for each value of \eqn{n}. For \eqn{n>1} uses a formula by Duntley (1942).
//' In case \eqn{n < 1}, uses an appropriate relation.
//'
//'
//' @return A vector of reflectances the same size as n
//'
//' @examples CalculateLambertianReflectances(c(0.5, 1, 2))
// [[Rcpp::export]]
Rcpp::NumericVector CalculateLambertianReflectances(Rcpp::NumericVector n) {
  // Calculate the reflectance of light incident with Lambertian (diffuse)
  // distribution on an interface with relative refractive index n =n2/n1,
  // moving from n1 to n2
  int numns = n.size();
  Rcpp::NumericVector output(numns);
  int i;
  for (i = 0; i < numns; i++) {
    if (n[i] >=1) {
      output[i] = get_lambertian_reflectance(n[i]);
    } else {
      output[i] = 1-(1-get_lambertian_reflectance(1/n[i]))*(n[i]*n[i]);
    }
  }
  return(output);
}
