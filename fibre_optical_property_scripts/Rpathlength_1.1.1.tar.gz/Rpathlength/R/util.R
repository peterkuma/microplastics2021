#' Run simulation for many parameters, to extract some property
#'
#' This takes a worker function as an argument, and runs that for each combination
#' of the parameters, `rbind`ing the results together.
#'
#' @param f Help funtion, that runs the simulation and extracts the relevant
#' result. This should take all all arguments in ... and does not need to
#' append the parameters to the result.
#' @param ... A list of named arguments, which are expanded to all combinations.
#' Values that should not be expanded, but passed as a vector, should be wrapped
#' in a `list()`. These are passed on to the worker function.
#' @param filename If not `NULL`, the file to write output to. If `rerun==FALSE`,
#' and the file given by filename exitst, returns the data in that file.
#' @param rerun Force a rerun. Only used if the file given by filename exists.
#' @param select_index Run only indices given in this (vector).
#' @param nthreads If > 1, use doParallel to run this many threads.
#' @param force_seed Add additional parameters to each run so that they all have
#' a different random seed.
#' @param seed_base Starting point of random seed (used with force_seed)
#' @return A data frame with all of the results in it.
#'
#' @export
#' @examples
#' params <- list(n2 = seq(1, 2, 0.1), n1 = 1, shape = 0,
#'                h = 1, alphasca = c(0, 1),
#'                list(shape_params = c(3/4, 1.5, 0, 0, 0, 0)))
#' run_over_parameters(mean_path_length_worker, params)
#'
#' @importFrom foreach %do%
#' @importFrom foreach %dopar%
#' @importFrom purrr cross
#' @importFrom foreach foreach
#' @importFrom parallel makeCluster
#' @importFrom doParallel registerDoParallel
#' @importFrom parallel stopCluster
run_over_parameters <- function(f, ..., filename = NULL, rerun = TRUE, select_index = FALSE, nthreads = 1,
                                force_seed = FALSE, seed_base = 0) {
  if (!rerun && !is.null(filename)) {
    if (file.exists(filename)) {
      # If we don't rerun, and a filename was specified, and the file exists
      # then we don't need to run, and can just return the file.
      return(readRDS(filename))
    }
  }

  # Get all possible parameters
  # We use a list, so that if a variable is a list, it's not
  # repeated (eg breaks)
  #
  params <- cross(.l = ...)
  nparams <- length(params)
  # Check indices in range
  select_index <- select_index[select_index > 0 & select_index <= nparams]
  # If specified, select only some indices
  if (any(select_index)) {
    params <- params[select_index]
    nparams <- length(params)
  }
  if (force_seed) {
    for (i in 1:nparams) {
      params[[i]][["set_seed"]] <- TRUE
      params[[i]][["seed"]] <- seed_base + i
    }
  }
  if (nthreads > 1 && nparams > 1) {
    cl <- parallel::makeCluster(nthreads)
    doParallel::registerDoParallel(cl)
    results <- foreach(
      i = 1:nparams, .combine = "rbind", .packages = c("dplyr")) %dopar% {
      params[[i]] %>% do.call(what = f)
    }
    stopCluster(cl)
  }else{
    results <- foreach(
      i = 1:nparams, .combine = "rbind") %do% {
      params[[i]] %>% do.call(what = f)
    }
  }
  if (!is.null(filename)) saveRDS(results, filename)
  return(results)
}


#' Calculate the mean path length for some parameters
#'
#' @param shape Arguments passed on to run_pathlength
#' @param shape_params Arguments passed on to run_pathlength
#' @param h Used to specify h, as a convenience.
#' @param n1 Arguments passed on to run_pathlength
#' @param n2 Arguments passed on to run_pathlength
#' @param alphaabs Arguments passed on to run_pathlength
#' @param alphasca Arguments passed on to run_pathlength
#' @param max_its Arguments passed on to run_pathlength
#' @param Nray Arguments passed on to run_pathlength
#' @param radius If specified, the radius to use when generating rays
#' @param ... Additional arguments passed to run_pathlength
#'
#' @return A one-row data.frame with appropriate parameters appended.
#' @export
#'
#' @examples
#' params <- list(n2 = seq(1, 2, 0.1), n1 = 1, shape = 0,
#'                h = 1, alphasca = c(0, 1),
#'                list(shape_params = c(3/4, 1.5, 0, 0, 0, 0)))
#' run_over_parameters(mean_path_length_worker, params)
#' @importFrom  magrittr %>%
#' @importFrom dplyr mutate
#' @importFrom dplyr select
mean_path_length_worker <- function(shape = 0, shape_params = generate_shape_params(shape, h)[[1]], h = 1,
                                    n1 = 1, n2 = 1, alphaabs = 0, alphasca = 0,
                                    max_its=1e3, Nray=1e3, radius=-1,
                                    ...) {
  passed <- (as.list(match.call())[-1]) # These are the explicitly-passed variables
  param_frame <- data.frame()
  for (s in names(passed)){
    if(s %in% names(list(...))){
      thisvar <- data.frame(list(...)[[s]])
    }else{
      thisvar <- data.frame(get(s))
    }
    if(nrow(thisvar)==1){
      names(thisvar) <- s
      param_frame <- c(param_frame, thisvar)
    }
  }
  param_frame <- as.data.frame(param_frame)
  if (radius < 0)radius <- min_radius(shape, list(shape_params)) + 0.1
    args <- list(Nray = Nray, shape = shape, shape_params = shape_params, make_summary = TRUE, n1 = n1,
               n2 = n2, alphasca = alphasca, alphaabs = alphaabs, max_its = max_its,
               ...,
               radius = radius)
  if (any(is.na(shape_params))) {
    warning("shape_params contains NA, skipping\n")
    return(data.frame())
  }

  result <- do.call(run_pathlength, args = args)
  param_frame <- param_frame %>% select(-intersect(names(param_frame),names(result[["summary"]])))
  result_summary <- result[["summary"]] %>%  cbind(param_frame)
  return(result_summary)

}



#' Calculate a histogram for some parameters
#'
#' @param shape Arguments passed on to run_pathlength
#' @param shape_params Arguments passed on to run_pathlength
#' @param h Used to specify h, as a convenience.
#' @param n1 Arguments passed on to run_pathlength
#' @param n2 Arguments passed on to run_pathlength
#' @param alphaabs Arguments passed on to run_pathlength
#' @param alphasca Arguments passed on to run_pathlength
#' @param max_its Arguments passed on to run_pathlength
#' @param Nray Arguments passed on to run_pathlength
#' @param breaks Arguments passed on to run_pathlength
#' @param logl Arguments passed on to run_pathlength
#' @param radius If specified, the radius to use when generating rays
#' @param ... Additional arguments passed to run_pathlength
#'
#' @return A data.frame with appropriate parameters appended.
#' @export
#'
#' @examples
#' library(ggplot2)
#' library(dplyr)
#' params <- list(Nray=1e5, n2 = seq(1, 2, 0.1), n1 = 1, shape = 0,
#'                h = 1, alphasca = c(0, 1),
#'                breaks=list(seq(from=-3, to=1, length.out=100)))
#' histogram_results <- run_over_parameters(histogram_worker, params)
#' ggplot(histogram_results %>% filter(is.finite(L)),
#' aes(L, pL, group = interaction(n2, alphasca), colour=n2))+
#' geom_path() +
#' scale_x_log10()+
#' facet_wrap(~alphasca)
#'
#' @importFrom  magrittr %>%
#' @importFrom dplyr mutate
#' @importFrom dplyr select
histogram_worker <- function(shape = 0, h = 1, shape_params = generate_shape_params(shape, h)[[1]],
                                    n1 = 1, n2 = 1, alphaabs = 0, alphasca = 0,
                                    max_its=1e3, Nray=1e3,
                             breaks = seq(from=-2, to=2, length.out=50),
                             logl = TRUE, radius=-1,
                                    ...) {
  passed <- (as.list(match.call())[-1]) # These are the explicitly-passed variables
  param_frame <- data.frame()
  for (s in names(passed)){
    if(s %in% names(list(...))){
      thisvar <- data.frame(list(...)[[s]])
    }else{
      thisvar <- data.frame(get(s))
    }
    if(nrow(thisvar)==1){
      names(thisvar) <- s
      param_frame <- c(param_frame, thisvar)
    }
  }
  param_frame <- as.data.frame(param_frame)
  if (radius < 0)radius <- min_radius(shape, list(shape_params)) + 0.1
  args <- list(Nray = Nray, shape = shape, shape_params = shape_params, make_summary = F, n1 = n1,
               n2 = n2, alphasca = alphasca, alphaabs = alphaabs, max_its = max_its,
               breaks =  breaks, logl = logl, ..., make_rays=F, radius = radius)
  if (any(is.na(shape_params))) {
    warning("shape_params contains NA, skipping\n")
    return(data.frame())
  }
  result <- do.call(run_pathlength, args = args)

  param_frame <- param_frame %>% select(-intersect(names(param_frame),names(result[["hist"]])))
  result_histogram <-  result[["hist"]] %>%  cbind(param_frame)
  return(result_histogram)

}



#' Calculate the bounce counts for some parameters
#'
#' @param shape Arguments passed on to run_pathlength
#' @param shape_params Arguments passed on to run_pathlength
#' @param h Used to specify h, as a convenience.
#' @param n1 Arguments passed on to run_pathlength
#' @param n2 Arguments passed on to run_pathlength
#' @param alphaabs Arguments passed on to run_pathlength
#' @param alphasca Arguments passed on to run_pathlength
#' @param max_its Arguments passed on to run_pathlength
#' @param Nray Arguments passed on to run_pathlength
#' @param radius If specified, the radius to use when generating rays
#' @param ... Additional arguments passed to run_pathlength
#'
#' @export
#' @return A data.frame with appropriate parameters appended.
#'
#' @examples
#' library(ggplot2)
#' library(dplyr)
#'  params <- list(Nray=1e5, n2 = c(1,2), n1 = 1, shape = 0,
#'                h = 1, alphasca = c(0, 1e-1, 1, 2),
#'                only_count_hitting = TRUE)
#'  bouncecount_results <- run_over_parameters(bounce_count_worker, params)
#'  ggplot(bouncecount_results,
#'  aes(bounces, Nscatter, colour=as.factor(alphasca), fill=as.factor(alphasca))) +
#'  geom_col(width=1, position=position_dodge()) + scale_y_log10()+
#'  facet_wrap(~n2, labeller=label_both)
#'
#' @importFrom  magrittr %>%
#' @importFrom dplyr mutate
#' @importFrom dplyr select
bounce_count_worker <- function(shape = 0, shape_params = generate_shape_params(shape, h)[[1]], h = 1,
                                    n1 = 1, n2 = 1, alphaabs = 0, alphasca = 0,
                                    max_its=1e3, Nray=1e3, radius = -1,
                                    ...) {
  passed <- (as.list(match.call())[-1]) # These are the explicitly-passed variables
  param_frame <- data.frame()
  for (s in names(passed)){
    if(s %in% names(list(...))){
      thisvar <- data.frame(list(...)[[s]])
    }else{
      thisvar <- data.frame(get(s))
    }
    if(nrow(thisvar)==1){
      names(thisvar) <- s
      param_frame <- c(param_frame, thisvar)
    }
  }
  param_frame <- as.data.frame(param_frame)
  if (radius < 0)radius <- min_radius(shape, list(shape_params)) + 0.1
  args <- list(Nray = Nray, shape = shape, shape_params = shape_params, make_summary = FALSE, n1 = n1,
               n2 = n2, alphasca = alphasca, alphaabs = alphaabs, max_its = max_its,
               ...,
               radius = radius, count_histogram = TRUE, make_rays = FALSE)
  if (any(is.na(shape_params))) {
    warning("shape_params contains NA, skipping\n")
    return(data.frame())
  }

  result <- do.call(run_pathlength, args = args)
  param_frame <- param_frame %>% select(-intersect(names(param_frame),names(result[["counthist"]])))

  result_summary <- result[["counthist"]] %>%  cbind(param_frame)
  return(result_summary)

}


#' Calculate the asymmetry parameter and associated quantities for some parameters
#'
#' @param shape Arguments passed on to run_pathlength
#' @param shape_params Arguments passed on to run_pathlength
#' @param h Used to specify h, as a convenience.
#' @param n1 Arguments passed on to run_pathlength
#' @param n2 Arguments passed on to run_pathlength
#' @param alphaabs Arguments passed on to run_pathlength
#' @param alphaabs Arguments passed on to run_pathlength (for low-absorption)
#' @param alphasca Arguments passed on to run_pathlength
#' @param max_its Arguments passed on to run_pathlength
#' @param Nray Arguments passed on to run_pathlength
#' @param radius If specified, the radius to use when generating rays
#' @param ... Additional arguments passed to run_pathlength
#'
#' @return A data.frame with appropriate parameters appended.
#' @export
#'
#' @examples
#' params <- list(n2 = seq(1, 2, 0.1), n1 = 1, shape = 0,
#'                h = 1, alphasca = c(0, 1),
#'                list(shape_params = c(3/4, 1.5, 0, 0, 0, 0)))
#' run_over_parameters(asymmetry_parameter_worker, params)
#' @importFrom  magrittr %>%
#' @importFrom dplyr mutate
asymmetry_parameter_worker <- function(shape = 0, shape_params = generate_shape_params(shape, h)[[1]], h = 1,
                                       n1 = 1, n2 = 1, alphaabs = 0, alphasca = 0,
                                       alphaabs_small = 1e-6,
                                       max_its=1e3, Nray=1e3,
                                       radius = -1,
                                       ...) {
  passed <- (as.list(match.call())[-1]) # These are the explicitly-passed variables
  param_frame <- data.frame()
  for (s in names(passed)){
    if(s %in% names(list(...))){
      thisvar <- data.frame(list(...)[[s]])
    }else{
      thisvar <- data.frame(get(s))
    }
    if(nrow(thisvar)==1){
      names(thisvar) <- s
      param_frame <- c(param_frame, thisvar)
    }
  }
  param_frame <- as.data.frame(param_frame)
  if (radius < 0)radius <- min_radius(shape, list(shape_params)) + 0.1

  calculate_g <- function(grt, x=10){
    #Calculates the asymmetry parameter g, the mean of cos(theta)

    data.frame(grt=grt) %>% mutate(gd=calculate_g_diffraction(x=x), g=(grt+gd)/2)

  }

  calculate_g_diffraction <- function(x, N=1000){
    #x size parameter of equivalent sphere
    theta <- seq(from=0, to=pi/2, length.out=N+1)
    #remove first point
    theta <- theta[seq(from=2, by=1, length.out=N)]
    dTheta <- theta[2] - theta[1]
    sum(2*besselJ(x*sin(theta), 1)^2/(tan(theta))*dTheta)
  }

  calculate_g_infinity <- function(n){

    g1 <- 8*n^4*(n^6 - 3*n^4 + n^2 - 1)/((n^4-1)^2*(n^2+1)^2)
    g2 <-  (n^2-1)^2*(n^8+12*n^6+54*n^4-4*n^2+1)/(16*(n^2+1)^4)
    g3 <- (3*n^12+3*n^11+25*n^10+25*n^9+22*n^8-282*n^7+138*n^6+186*n^5+151*n^4-89*n^3 + 13*n^2 - 3*n)/(24*(n^2+1)^2*(n^4-1)*(n+1))

    ginf <- (1+g1*log(n) - g2*log((n+1)/(n-1)) + g3) / (1 + CalculateLambertianReflectances(n))
    ginf
  }

  args_c0 <- list(Nray = Nray, shape = shape, shape_params = shape_params, make_summary = TRUE, n1 = n1,
                  n2 = n2, alphasca = alphasca, alphaabs = 0, max_its = max_its,
                  ..., radius = radius)
  args_csmall <- list(Nray = Nray, shape = shape, shape_params = shape_params, make_summary = TRUE, n1 = n1,
                      n2 = n2, alphasca = alphasca, alphaabs = alphaabs_small, max_its = max_its,
                      ..., radius = radius)
  if (any(is.na(shape_params))) {
    warning("shape_params contains NA, skipping\n")
    return(data.frame())
  }

  result_c0 <- do.call(run_pathlength, args = args_c0)
  result_csmall <- do.call(run_pathlength, args = args_csmall)
  ginf <- calculate_g_infinity(n2)
  g0 <- result_c0[["summary"]] %>% pull(g)
  lmean <- result_c0[["summary"]] %>% pull(lmean)
  gsmall <- result_csmall[["summary"]] %>% pull(g)
  SA <- surface_area(shape, list(shape_params))
  Cabssmall <- result_csmall[["summary"]] %>% mutate(Cabs = Nabsorbed/Nray) %>% pull(Cabs) * SA/4

  V <- volume(shape, list(shape_params))

  chi <- alphaabs_small/(4*pi)
  psi <- 2*Cabssmall/(3*4*pi*chi*V*(1-CalculateLambertianReflectances(n2)))
  beta <- (gsmall-g0)/((ginf-g0)*alphaabs_small)
  res_df <- data.frame(lmean=lmean, g0=g0, ginf=ginf, beta=beta, psi=psi, Cabssmall=Cabssmall)
  param_frame$alpha_abs <- alphaabs_small
  param_frame <- param_frame %>% select(-intersect(names(param_frame),names(res_df)))
  result_summary <- res_df %>%  cbind(param_frame)
  return(result_summary)

}
