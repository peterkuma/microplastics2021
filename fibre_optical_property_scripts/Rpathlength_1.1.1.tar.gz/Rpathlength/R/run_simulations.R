#' Make a histogram
#'
#' @param x A  vector to make a histogram from
#' @param ... Parameters passed to hist()
#'
#' @return A histogram of x as a data.frame, with columns mids, counts, density, width
#'
#' @details This creates a histogram, making use of hist(), but if breaks are passed as an argument,
#'  it modifies the data so that any points outside of the range of breaks are remapped to the
#'  relevant limit.
#'
#'  If breaks is specified, it should be evenly spaced, otherwise the `width` field will be incorrect.
#' @export
#'
#' @seealso hist
#' @examples
#' \dontrun{histogram <- make_hist(mtcars[["cyl"]], breaks=seq(from=4, to=8))}
#'
#' @importFrom graphics hist
make_hist <- function(x, ...) {
  dots <- list(...)
  if ("breaks" %in% names(dots)) {
    minx <- min(dots[["breaks"]])
    maxx <- max(dots[["breaks"]])
    x <- pmin(pmax(x, minx), maxx)
  }
  y <- hist(x, plot = FALSE, ...)
  breaks <- y[["breaks"]]
  #  browser()
  widths <- breaks[2:length(breaks)] - breaks[1:(length(breaks) - 1)]
  invisible(data.frame(mids = y[["mids"]], counts = y[["counts"]], density = y[["density"]], width = widths))
}
